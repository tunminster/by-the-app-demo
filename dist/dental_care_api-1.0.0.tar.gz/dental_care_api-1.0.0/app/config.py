AZURE_STORAGE_CONTAINER = 'bytheapp-training-data'
TRAINING_BLOB_DATA_FILE = 'training_data.csv'
AZURE_STORAGE_VOICE_CONTAINER = 'bytheapp-voice-data'