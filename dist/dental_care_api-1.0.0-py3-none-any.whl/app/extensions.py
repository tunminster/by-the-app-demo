from flask_caching import Cache

# Initialize the cache
cache = Cache()